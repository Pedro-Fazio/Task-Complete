package com.crudGame.TaskComplete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskCompleteApplicationTests {

	@Test
	void contextLoads() {
	}

}
