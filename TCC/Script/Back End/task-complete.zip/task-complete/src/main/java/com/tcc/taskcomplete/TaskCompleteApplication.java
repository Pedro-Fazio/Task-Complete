package com.tcc.taskcomplete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskCompleteApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskCompleteApplication.class, args);
	}

}
